// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'recipes_categories_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$recipeCategoriesHash() => r'b84adba1f37a0f6ed9133d20218903d4b1a666c4';

/// See also [recipeCategories].
@ProviderFor(recipeCategories)
final recipeCategoriesProvider =
    AutoDisposeFutureProvider<List<RecipeCategory>>.internal(
  recipeCategories,
  name: r'recipeCategoriesProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$recipeCategoriesHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef RecipeCategoriesRef
    = AutoDisposeFutureProviderRef<List<RecipeCategory>>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
